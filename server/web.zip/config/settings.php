<?php

    return [
        'covers'=>[
            'header_logo',
            'footer_logo',
            'favicon'
        ]

    ];
