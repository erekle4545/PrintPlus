<?php
return [

    /**
     * menu activation status
     */
    'status' => [
        'active' => 0,
        'inactive' => 1,

    ],

    /** menu position options  */
    'positions' => [
        'header'    => ['id' => 1, 'description' => 'Header Menu'],
//        'footer'    => ['id' => 2, 'description' => 'Footer Menu'],
        'hidden'    => ['id' => 3, 'description' => 'Hidden Menu'],
//        'both'      => ['id' => 4, 'description' => 'Both Menu'],
        'school'      => ['id' => 5, 'description' => 'Our School'],
        'courses_program'=> ['id' => 6, 'description' => 'Courses And Program'],
    ],

    'dropdown' => [
        'types' => [
            'none'      => ['value' => '0', 'description' => 'No Dropdown'],
            'children'  => ['value' => '1', 'description' => 'Child Elements'],
        ]
    ]
];
