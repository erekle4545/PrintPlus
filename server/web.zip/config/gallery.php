<?php
return [

    'covers' => [
        'gallery_thumb',
        'video',
        'gallery'
    ],
];
