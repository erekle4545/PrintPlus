<?php
return [
    'covers'=>[
        'default',
        'slider_background'
    ]
];
