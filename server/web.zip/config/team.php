<?php
return [
  'covers'=>[
        'default',
        'user_avatar',
  ],
];
