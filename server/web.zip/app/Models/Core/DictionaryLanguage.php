<?php

namespace App\Models\Core;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DictionaryLanguage extends Model
{
    use HasFactory;

    protected $fillable = [
        'dictionary_id',
        'language_id',
        'value',
    ];


}
