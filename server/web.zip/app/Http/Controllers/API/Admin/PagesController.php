<?php

namespace App\Http\Controllers\API\Admin;
use App\Helpers\Core\Multitenant;
use App\Models\Core\Cover;
use App\Models\Core\Menu;
use App\Models\Core\MenuLanguage;
use DB;
use App\Events\Menu\MenuChanged;
use App\Http\Controllers\Controller;
use App\Http\Resources\PageResource;
use App\Models\Core\Page;
use App\Models\Core\PageLanguage;
use App\Http\Requests\StorePagesRequest;
use App\Http\Requests\UpdatePagesRequest;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class PagesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $pages = Page::query();

        if ($request->keyword) {
             $pages->whereHas('info', function ($query) use ($request) {
                $query->with('covers');
                $query->where('language_id', $request->language_id);
                $query->where('title', 'like', '%' . $request->keyword . '%');
            })->with('info.covers');

        } else {
            $pages->with(array('info' => function ($query) use ($request) {
                $query->with('covers');
                $query->where('language_id', $request->language_id);
            }));
            $pages->with(array('info' => function ($query) use ($request) {
                $query->with('covers');
                $query->where('language_id', $request->language_id);
            }));
        }

        if ($request->template_id) {
            $pages->where('template_id', $request->template_id);
        }
        if ($request->status) {
            $pages->where('status', $request->status);
        }

        $pages->orderBy('created_at', 'desc');

        return new PageResource($pages->paginate(10));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\StorePagesRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StorePagesRequest $request)
    {
        DB::beginTransaction();

        try {
            if ($request->id) {
                $page = Page::findOrFail($request->id);
            } else {

                $metas = [];
                $page = Page::Create([
                    'type'          => $request->type,
                    'template_id'   => $request->template_id,
                    'status'        => $request->status,
                    'tasks'        => $request->tasks,
                    'show_home_page' => $request->show_home_page?:0,
                    'meta'          => $metas
                ]);
            }

            /**
             * Collect Facebook og tags
             */
            $og_tags['facebook'] = [
                'og' => [
                    'title'         => $request->fb_og_title,
                    'description'   => $request->fb_og_description,
                    'url'           => $request->fb_og_url,
                    'type'          => $request->fb_og_type,
                ]
            ];

            $meta_merged = $request->meta ? array_merge($og_tags, $request->meta) : $og_tags;
            $meta_merged = array_merge($meta_merged, ['meta_keywords' => $request->meta_keywords ?:[]]);

            /**
             * Try to save page language
             */
            $pageLanguage = PageLanguage::Create([
                'page_id'       => $page->id,
                'language_id'   => $request->language_id,
                'title'         => $request->title,
                'description'   => $request->description?:" ",
                'text'          => $request->text,
                'meta'          => $meta_merged,
                'slug'          => $request->slug,
            ]);

            if($request->cover_id) {

                /**
                 *  covers
                 */
                foreach ($request->cover_id as $key => $value) {
                    Cover::Create([
                        'files_id'        => $value,
                        'cover_type'     => $request->cover_type[$key],
                        'coverable_type' => Multitenant::getModel('PageLanguage'),
                        'coverable_id'   => $pageLanguage->id,
                    ]);
                }
            }


            DB::commit();

            if ($request->assign_page) {
                $this->assignToMenu($request, $page->id);
            }

            $resData = [
                'id'=>$page->id,
                'info'=>$pageLanguage
            ];
            event(new MenuChanged());
            return response($resData, 200)->header('Content-Type', 'application/json');
        } catch (\Exception $e) {
            DB::rollBack();
            return response(['result' => $e->getMessage()], 500)->header('Content-Type', 'application/json');
        }
    }

    /**
     * @param $request
     * @param $page_id
     */
    public function assignToMenu($request, $page_id)
    {
        DB::beginTransaction();
        try {
            $menu = Menu::Create([
                'active'    => 1,
                'page_id'   => $page_id,
                'type'      => Config('menu.positions.header.id'),
//                'dropdown'  => Config('menu.dropdown.types.children.value'),
//                'meta'      => [],
            ]);

            /**
             * Collect Facebook og tags
             */
//            $og_tags['facebook'] = [
//                'og' => [
//                    'title'         => $request->fb_og_title,
//                    'description'   => $request->fb_og_description,
//                    'url'           => $request->fb_og_url,
//                    'type'          => $request->fb_og_type,
//                ]
//            ];

            $menu_lang = MenuLanguage::Create([
                'menu_id'       => $menu->id,
                'language_id'   => $request->language_id,
                'title'         => $request->title,
                'description'   => $request->description,
                'slug'          => $request->slug,
//                'meta'          => $og_tags,
            ]);

            if ($request->cover_id) {
                /**
                 * Attach covers
                 */
                $coverModel = Multitenant::getModel('Cover');

                foreach ($request->cover_id as $key => $value) {
                    $coverModel::Create([
                        'files_id'        => $value,
                        'coverable_type' => Multitenant::getModel('MenuLanguage'),
                        'coverable_id'   => $menu_lang->id,
                    ]);
                }
            }

            DB::commit();
            event(new MenuChanged());
        } catch (\Exception $e) {
            DB::rollBack();
            return response(['result' => $e->getMessage()], 500)->header('Content-Type', 'application/json');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Core\Pages  $pages
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request,$id)
    {
        $model = Multitenant::getModel('Page');
        try {
            //Find page with id and language id
            $page = $model::with(['info' => function ($query) use ($request) {
                $query->where('language_id', $request->language_id);

            }, 'info.covers'])->findOrFail($id);
            //if we can not find page with id and language, select very first page ignoring languge
            if (is_null($page->info)) {
                $page = $model::with(['info','info.covers'])->findOrFail($id);
            }



        } catch (Exception $e) {
            return response(['result' => 'not found'], 404)->header('Content-Type', 'application/json');
        }
        return new PageResource($page);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Core\Page  $page
     * @return \Illuminate\Http\Response
     */
    public function edit(Page $page)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\UpdatePagesRequest  $request
     * @param  \App\Models\Core\Pages  $pages
     * @return \Illuminate\Http\Response
     */
    public function update(UpdatePagesRequest $request, $id)
    {

        try {
            //Find Page
            $page = Page::with(['info' => function ($query) use ($request) {
                $query->where('language_id', $request->language_id);
            }, 'infos.covers'])->findOrFail($id);
            //'info.covers'
            //If status is other then current change it
            $metas = ['searchable' => isset($request->searchable) ? $request->searchable : false, 'withtitle' => isset($request->withtitle) ? $request->withtitle : false];
            if (isset($request->unlisted) && $request->unlisted) {
                $metas['unlisted'] = true;
            } else {
                unset($metas['unlisted']);
            }

            if (isset($request->excluded) && $request->excluded) {
                $metas['excluded'] = true;
            } else {
                unset($metas['excluded']);
            }
            $page->type = $request->type;
            $page->status = $request->status;
            $page->tasks = $request->tasks;
            $page->show_home_page = $request->show_home_page?:0;
            $page->template_id = $request->template_id;
//            $page->meta = $metas;
            $page->save();



            /**
             * Attache covers
             */
            if (!is_null($page->info)) {
                $coverModel = Multitenant::getModel('Cover');
                $coverModel::where('coverable_type', Multitenant::getModel('PageLanguage'))->where('coverable_id', $page->info->id)->delete();
            }
            if ($request->cover_id) {

                //Remove covers
                if (!is_null($page->info)) {
                     foreach ($request->cover_id as $key => $value) {
                        $coverModel::Create([
                            'files_id'        => $value,
                            'cover_type'     => $request->cover_type[$key],
                            'coverable_type' => Multitenant::getModel('PageLanguage'),
                            'coverable_id'   => $page->info->id,
                        ]);
                    }
                }
            }

            //Update page language
            if (!is_null($page->info)) {

                /**
                 * Collect Facebook og tags
                 */
                $og_tags['facebook'] = [
                    'og' => [
                        'title' => $request->fb_og_title,
                        'description' => $request->fb_og_description,
                        'url' => $request->fb_og_url,
                        'type' => $request->fb_og_type,
                    ]
                ];

                $meta_merged = $request->meta ? array_merge($og_tags, $request->meta) : $og_tags;
                $meta_merged = array_merge($meta_merged, ['meta_keywords' => $request->meta_keywords ?: []]);

                $page->info->title = $request->title;
                $page->info->slug = $request->slug;
                $page->info->description = $request->description ?: " ";
                $page->info->text = $request->text;
                $page->info->meta = $meta_merged;
                $page->info->save();
                //sleep(10);

                $gt = Menu::where('page_id',$page->id)->first();
                $menu = Menu::with(['info' => function ($query) use ($request) {
                    $query->where('language_id', $request->language_id);
                }, 'info'])->findOrFail($gt->id);

                if (!is_null($menu->info)) {
                    $menu->info->update(['slug'=>$request->slug]);
                }

                event(new MenuChanged());

                return new PageResource($page);

            }else{
                /**
                 * Collect Facebook og tags
                 */
                $og_tags['facebook'] = [
                    'og' => [
                        'title' => $request->fb_og_title,
                        'description' => $request->fb_og_description,
                        'url' => $request->fb_og_url,
                        'type' => $request->fb_og_type,
                    ]
                ];

                $meta_merged = $request->meta ? array_merge($og_tags, $request->meta) : $og_tags;
                $meta_merged = array_merge($meta_merged, ['meta_keywords' => $request->meta_keywords ?: []]);

                $pageLangModel = PageLanguage::Create([
                    'page_id'       => $page->id,
                    'language_id'   => $request->language_id,
                    'title'         => $request->title,
                    'description'   => $request->description?:" ",
                    'text'          => $request->text,
                    'meta'          => $meta_merged,
                    'slug'          => $request->slug,
                ]);
                if ($request->cover_id) {
                    $coverModel = Multitenant::getModel('Cover');
                    //Remove covers
                     foreach ($request->cover_id as $key => $value) {
                        $coverModel::Create([
                            'files_id'        => $value,
                            'cover_type'     => $request->cover_type[$key],
                            'coverable_type' => Multitenant::getModel('PageLanguage'),
                            'coverable_id'   => $pageLangModel->id,
                        ]);
                    }

                }
            }



        } catch (\Exception $e) {
            return response(['result' => 'not found'], 404)->header('Content-Type', 'application/json');
        }
    }

    /**
     * @param Page $page
     * @param Request $request
     * @param $id
     * @return \Illuminate\Contracts\Foundation\Application|\Illuminate\Contracts\Routing\ResponseFactory|\Illuminate\Foundation\Application|\Illuminate\Http\Response|\Response
     *
     */
    public function destroy(Request $request,$id)
    {
        //        $id = explode(",",$id);


        $pages = Page::where('id', $id)->with('infos')->first();

        if ($pages->infos->count() > 1) {
            Menu::where(['page_id' => $id])->delete();
            Page::where('id', $id)->delete();
            PageLanguage::where(['page_id' => $id, 'language_id' => $request->language_id])->delete();
        } else {
            Menu::where(['page_id' => $id])->delete();
            PageLanguage::where(['page_id' => $id])->delete();
            Page::where('id', $id)->delete();
        }

        return response(['result' => $pages], 200)->header('Content-Type', 'application/json');

    }



    public function pageSideBar(Request $request){
        $pages = Page::with(['info' => function ($query) use ($request) {
            $query->where('language_id', $request->language_id);
        }])->limit(5)->orderBy('created_at','DESC')->get();
        return new PageResource($pages);

    }

}
