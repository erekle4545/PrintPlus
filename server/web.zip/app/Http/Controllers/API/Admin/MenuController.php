<?php

namespace App\Http\Controllers\API\Admin;
use App\Helpers\Core\Multitenant;
use App\Models\Core\Page;
use Complex\Exception;
use DB;
use App\Http\Controllers\Controller;
use App\Http\Resources\MenuResource;
use App\Events\Menu\MenuChanged;
use App\Models\Core\Menu;
use App\Http\Requests\StoreMenuRequest;
use App\Http\Requests\UpdateMenuRequest;
use App\Models\Core\MenuLanguage;
use Illuminate\Http\Request;

class MenuController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $model = Multitenant::getModel('Menu');
            if ($request->options) {
                $options = [];
                $editingMenu = null;

                if ($request->id) {
                    $editingMenu = Multitenant::getModel('Menu')::withDepth()->find($request->id);
                }

                $traverse = function ($collection, $parent = null) use (&$traverse, &$menus, $editingMenu) {
                    foreach ($collection as $key => $menu) {
                        $menu['value'] = $menu->id;
                        $menu['label'] = $menu->info['title'];
                        $menu['children'] = $menu->children;

                        if (!is_null($editingMenu)) {
                            $menu['disabled'] = $menu->id >= $editingMenu->id;
                        }

                        if ($menu->children) {
                            if ($menu->children->count() === 0) {
                                unset($menu->children);
                            } else {
                                $traverse($menu->children, $menu);
                            }
                        }
                    }
                };

                $menu = $model::with(['info' => function ($query) use ($request) {
                    $query->where('language_id', $request->language_id);
                }, 'info'])->orderBy('order', 'asc')->getModels()->get()->toTree();

                $traverse($menu);
                return new MenuResource($menu);
            }

        return new MenuResource($menu = $model::with(['info' => function ($query) use ($request) {
            $query->where('language_id', $request->language_id?:1);
        },])->orderBy('order', 'asc')->withDepth()->get()->toTree());
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\StoreMenuRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreMenuRequest $request)
    {
        if ($request->has_custom_link === true) {
            return $this->storeCutomMenu($request);
        }

        DB::beginTransaction();

        try {
            if ($request->id) {
                $menu = Menu::findOrFail($request->id);
            } else {
                $menu = Menu::Create([
                    'active'    => $request->active,
                    'page_id'   => $request->page_id,
                    'type'      => $request->type,
                    'dropdown'  => $request->dropdown,
//                    'meta'      => [],
                ]);
            }

            $model = MenuLanguage::query();

            /**
             * Collect Facebook og tags
             */
            $og_tags['facebook'] = [
                'og' => [
                    'title'         => $request->fb_og_title,
                    'description'   => $request->fb_og_description,
                    'url'           => $request->fb_og_url,
                    'type'          => $request->fb_og_type,
                ]
            ];

            $meta_merged = $request->meta ? array_merge($og_tags, $request->meta) : $og_tags;

            $menu_lang = MenuLanguage::Create([
                'menu_id'       => $menu->id,
                'language_id'   => $request->language_id,
                'title'         => $request->title,
//              'description'   => $request->description,
                'slug'          => $request->slug,
                'meta'          => $meta_merged,
            ]);

            /**
             * If parent id provided find and set as parent
             */
            if ($request->parent_id && $request->parent_id != $menu->parent_id) {
                $parent = Menu::find($request->parent_id);
                $parent->appendNode($menu);
            }

            if ($request->cover_id) {
                /**
                 * Attache covers
                 */
                $coverModel = Multitenant::getModel('Cover');

                foreach ($request->cover_id as $key => $value) {
                    $coverModel::Create([
                        'file_id'        => $value,
                        'coverable_type' => MenuLanguage::query(),
                        'coverable_id'   => $menu_lang->id,
                    ]);
                }
            }
            event(new MenuChanged());
            DB::commit();
            return response(['id' => $menu->id], 200)->header('Content-Type', 'application/json');
        } catch (\Exception $e) {
            DB::rollBack();
            return response(['result' => $e->getMessage()], 500)->header('Content-Type', 'application/json');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Core\Menu  $menu
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request,$id)
    {
        try{
            $menus = Menu::with(['info'=> function ($query) use ($request){
                $query->where('language_id', $request->language_id);
            },'infos'])->findOrFail($id);

            if(is_null($menus->info)){
                 $menus = Menu::with(['info','info'])->findOrFail($id);
            }
        } catch (Exception $e) {
            return response(['result' => 'not found'], 404)->header('Content-Type', 'application/json');
        }

        return new MenuResource($menus);

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Core\Menu  $menu
     * @return \Illuminate\Http\Response
     */
    public function edit(Menu $menu)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\UpdateMenuRequest  $request
     * @param  \App\Models\Core\Menu  $menu
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateMenuRequest $request, Menu $menu,$id)
    {
        $model = Multitenant::getModel('Menu');
        try {
            //Find Menu
            $menu =$model::with(['info' => function ($query) use ($request) {
                $query->where('language_id', $request->language_id);
            }, 'info.covers'])->findOrFail($id);

            $menu->active   = $request->active;
            $menu->page_id  = $request->page_id;
            $menu->type     = $request->type;
            $menu->dropdown = $request->dropdown;

            $meta = $menu->meta;
            $meta['custom_link'] = false;

            if ($request->has_custom_link === true) {
                $meta['custom_link'] = true;
            }

            if ($request->parent_id) {
                $menu->parent_id = $request->parent_id;
            } else {
                $menu->makeRoot();
            }

            $menu->meta = $meta;
            $menu->save();

            //Remove covers
//            $coverModel = Multitenant::getModel('Cover');
//            $coverModel::where('coverable_type', Multitenant::getModel('MenuLanguage'))->where('coverable_id', $menu->info->id)->delete();

            /**
             * Attache covers
             */
//            if ($request->cover_id) {
//                foreach ($request->cover_id as $key => $value) {
//                    $coverModel::Create([
//                        'file_id'        => $value,
//                        'coverable_type' => Multitenant::getModel('MenuLanguage'),
//                        'coverable_id'   => $menu->info->id,
//                    ]);
//                }
//            }

            //Update menu language
            if (!is_null($menu->info)) {
                /**
                 * Collect Facebook og tags
                 */
                $og_tags['facebook'] = [
                    'og' => [
                        'title'         => $request->fb_og_title,
                        'description'   => $request->fb_og_description,
                        'url'           => $request->fb_og_url,
                        'type'          => $request->fb_og_type,
                    ]
                ];

                $meta_merged = $request->meta ? array_merge($og_tags, $request->meta) : $og_tags;
                $menu->info->title = $request->title;
                $menu->info->description = $request->description;
                $menu->info->slug = $request->slug;
                $menu->info->meta = $meta_merged;
                $menu->info->save();

            }else {
                $og_tags['facebook'] = [
                    'og' => [
                        'title'         => $request->fb_og_title,
                        'description'   => $request->fb_og_description,
                        'url'           => $request->fb_og_url,
                        'type'          => $request->fb_og_type,
                    ]
                ];

                $meta_merged = $request->meta ? array_merge($og_tags, $request->meta) : $og_tags;

                MenuLanguage::Create([
                    'menu_id'       => $menu->id,
                    'language_id'   => $request->language_id,
                    'title'         => $request->title,
//                  //'description'   => $request->description,
                    'slug'          => $request->slug,
                    'meta'          => $meta_merged,
                ]);
            }
            event(new MenuChanged());
            return new MenuResource($menu);
        } catch (Exception $e) {
            return response(['result' => 'not found'], 404)->header('Content-Type', 'application/json');
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Core\Menu  $menu
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, $id)
    {

        $Menus = Menu::where('id', $id)->with('infos')->first();

        if ($Menus->infos->count() > 1) {
            MenuLanguage::where(['menu_id' => $id, 'language_id' => intval($request->language_id)])->delete();

            return response(['result' => 'Menu item deleted successfully', 'status' => 'success'], 200)->header('Content-Type', 'application/json');
        } else {
            MenuLanguage::where(['menu_id' => $id])->delete();
            Menu::where('id', $id)->delete();

            return response(['result' => 'Menu with items deleted successfully', 'status' => 'success'], 200)->header('Content-Type', 'application/json');
        }

        return response(['result' => 'Not Found', 'status' => 'danger'], 404)->header('Content-Type', 'application/json');
    }




    protected function storeCutomMenu(Request $request)
    {
        DB::beginTransaction();
        $meta = [];
        try {
            if ($request->id) {
                $menu = Menu::findOrFail($request->id);
            } else {
                $meta['custom_link'] = true;
                $menu = Menu::Create([
                    'active'    => $request->active,
                    'page_id'   => null,
                    'type'      => $request->type,
                    'dropdown'  => 0,
                    'meta'      => $meta,
                ]);
            }

            $model = MenuLanguage::query();

            $menu_lang = MenuLanguage::Create([
                'menu_id'       => $menu->id,
                'language_id'   => $request->language_id,
                'title'         => $request->title,
                'description'   => $request->description,
                //'slug'          => preg_replace('/^\//', '', $request->slug),
                'slug'          => preg_replace('/^\/+/', '', $request->slug),
//                'meta'          => [],
            ]);

            /**
             * If parent id provided find and set as parent
             */
            if ($request->parent_id && $request->parent_id != $menu->parent_id) {
                $menuModel = Menu::query();
                $parent = Menu::find($request->parent_id);
                $parent->appendNode($menu);
            }
            DB::commit();
            event(new MenuChanged());
            return response(['id' => $menu->id], 200)->header('Content-Type', 'application/json');
        } catch (\Exception $e) {
            DB::rollBack();
            return response(['result' => $e->getMessage()], 500)->header('Content-Type', 'application/json');
        }
    }


    /**
     * [updateSortPosition description]
     * @param  Request $request [description]
     * @return [type]           [description]
     */
    public function updateSortPosition(Request $request)
    {
        //Make all menu items to be parent before proceeding
        $menuModel = Menu::query();
        $menu =Menu::get();
        $menu->filter(function ($menu) {
            $menu->makeRoot()->save();
        });

        $this->updateSort($request->pages);
        event(new MenuChanged());
        return $this->index($request);
    }

    /**
     * [updatePosition description]
     *
     * @param  Request $request [description]
     * @return
     */
    protected function updateSort($menus, $parent_id = 0, $order = 1)
    {
        $data = [];
        $parentMenu = "";
        $node       = "";

        foreach ($menus as $menu) {
            $parentMenu = Menu::where('id', $parent_id)->first();
            $node       = Menu::where('id', $menu['id'])->first();
            $data[] = $menu['id'];

            $input['order'] = $order++;
            Menu::where('id', $menu['id'])->update($input);

            if (!is_null($parentMenu)) {
                $node->appendToNode($parentMenu)->save();
            } else {
                $input['parent_id']= 0;
                Menu::where('id', $menu['id'])->update($input);
            }
            if (!empty($menu['children'])) {
                $this->updateSort($menu['children'], $menu['id']);
            }
        }
    }
}
