<?php

                return ['carsTitle'=>'testtarget',
	'targetLink'=>'ბანერის ლინკი',
	 ];