<?php

                return ['logoText'=>'N1 public school of St. Bolnisi named after Sulkhan Saba Orbeliani of LSI',
	'slogan'=>'traditionally the first',
	'search'=>'Search',
	'readMore'=>'Read More',
	'coursesAndProgram'=>'Courses And Program',
	'allNews'=>'All News',
	'courseAndOlympiad'=>'Course And Olympiad',
	'participant'=>'Participant',
	'result'=>'Result',
	'contact'=>'Contact',
	'urls'=>'Urls',
	'phone'=>'Phone',
	'address'=>'Address',
	'codMedia'=>'Follow Us',
	'newsSubscribe'=>'Subscribe News',
	'subscribe'=>'Subscribe',
	'email'=>'Email',
	'newsSubscribeText'=>'Subscribe to the page and be the first to learn about the study process and other news                                  regarding',
	'createdBy'=>'created By',
	'copyRight'=>'Copy Right',
	'home'=>'Home',
	'details'=>'Details',
	'photo'=>'Photo',
	'video'=>'Video',
	'ourSchool'=>'Our School',
	'article'=>'article',
	'page'=>'Page',
	'no-result'=>'No Result',
	'fullName'=>'Full Name',
	'subject'=>'Subject',
	'yourMessage'=>'Your Message',
	'send'=>'Send',
	'haveQuestion'=>'do you have a question?',
	 ];