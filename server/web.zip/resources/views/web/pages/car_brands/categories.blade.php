@extends('layouts.app')
@section('content')
    <div class="all-title-box"  style="background-image: url('{{Helper::getThumbImage(!is_null($page->info)?$page->info->covers:[],config('files.covers.page_cover.id'))}}');">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h2>{{Helper::checkInfo($page,'title')}}</h2>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="{{url()->previous() }}">{{Language::translate('back')}}</a></li>
                        <li class="breadcrumb-item active">{{Helper::checkInfo($page,'title')}}</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>


    <div class="products-box">
        <div class="container">

            <div class="row special-list">

                @foreach($page->categories as $row)
                        <div class="col-lg-3 col-md-6 special-grid best-seller">
                            <div class="products-single fix">
                                <div class="box-img-hover"  style="cursor: pointer" onclick="location.href=('{{Helper::makeUrl($row->page->info->slug.'?category_id='.$row->id)}}')">

                                    <img src="{{Helper::getThumbImage(!is_null($row->info)?$row->info->covers:[],config('files.covers.default.id'))}}" class="img-fluid" alt="Image">

                                </div>
                                <div class="why-text">
                                    <a href="{{Helper::makeUrl(Helper::makeUrl($row->page->info->slug.'?category_id='.$row->id))}}" > <h4>{{Helper::checkInfo($row,'title')}}</h4></a>
                                </div>
                            </div>
                        </div>
                @endforeach
                <!-- end test -->

            </div>
            <div class="pagination">
{{--                {{ $page->categories->fragment('foo')->links('pagination::bootstrap-4') }}--}}

            </div>
        </div>
    </div>

@stop
