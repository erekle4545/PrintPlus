<h1 style="color: #4485b8;">კონტაქტის ფორმა</h1>
<p><strong style="color: #000;">მომხმარებლის სახელი:</strong> {{$data['username']}}<br /><em></em></p>
<p><strong style="color: #000;">ელ-ფოსტა:</strong> {{$data['email']}}<br /><em></em></p>
<p><strong style="color: #000;">თემა:</strong> {{$data['object']}}<br /><em></em></p>
<hr />
<p><strong style="color: #000;">ტექსტი:</strong> {{$data['text']}}<br /><em></em></p>
<p><em>&copy;  </em></p>
