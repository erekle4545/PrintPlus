<h1 style="color: #4485b8;">ახალი გამომწერი</h1>
<p><strong style="color: #000;">ელ-ფოსტა:</strong> {{$data['email']}}<br /><em></em></p>
<hr />
<p><em>&copy; sso.edu.ge</em></p>
