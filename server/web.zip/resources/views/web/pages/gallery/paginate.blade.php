<div class="pagination">
    <ul class="pagination-lists">
        <li class="pagination-list"><a class="pagination-link" href="#">1</a></li>
        <li class="pagination-list"><a class="pagination-link" href="#">2</a></li>
        <li class="pagination-list"><a class="pagination-link" href="#">3</a></li>
        <li class="pagination-list next"><a class="pagination-link" href="#">შემდეგი</a>
            <svg width="10" height="10" viewBox="0 0 10 10" fill="none"
                 xmlns="http://www.w3.org/2000/svg">
                <path d="M1 9L5 4.84709L0.999999 0.694171" stroke="#363636" />
                <path d="M5 9L9 4.84709L5 0.694171" stroke="#363636" />
            </svg>
        </li>
    </ul>
</div>
